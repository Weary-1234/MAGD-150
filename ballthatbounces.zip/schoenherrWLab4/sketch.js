//varables for the bouncing circle.
//circle radius
let radius = 25;
//center point location of the circle
let xLoc;
let yLoc;
//gives the detection cords.
let topDetect;
let rightDetect;
let leftDetect;
let bottomDetect;
//velocity of the circle
let virtVel;
let horzVel;
//keeps track of the total bounces
let bounces = 0;

//variables for the legaly required circle
let whatX;
let whatY;

//variables for text
let textX;
let textY;
let shake = 0;

function setup() {
  createCanvas(400, 400);
  //sets the variables above
  xLoc = 199;
  yLoc = 199;
  topDetect = yLoc-radius;
  rightDetect = xLoc+radius;
  leftDetect = xLoc-radius;
  bottomDetect = yLoc+radius;
  virtVel = random(-5,5);
  horzVel = random(-5,5);

  whatX = random(100,300);
  whatY = random(100, 300);
  
  frameRate(30);

  textX = width/2;
  textY = height/2;
  textSize(32);
  textAlign(CENTER);
}

function draw() {
  background(50);
  bounceTrack();
  dumbCircle();
  circle(xLoc,yLoc,radius*2);

  if(sqrt(horzVel) == null){
    horzPos = false;
  }else{
    horzPos = true;
  }
  if(sqrt(virtVel) == null){
    virtPos = false;
  }else{
    virtPos = true;
  }

  if(topDetect <= 0){
    horzVel*=-1;
    bounces++;
    shake+=5;
  }
  if(rightDetect >= width){
    virtVel*=-1;
    bounces++;
    shake+=5;
  }
  if(leftDetect <= 0){
    virtVel*=-1;
    bounces++;
    shake+=5;
  }
  if(bottomDetect >= height){
    horzVel*=-1;
    bounces++;
    shake+=5;
  }

  xLoc+=virtVel;
  yLoc+=horzVel;
  topDetect = yLoc-radius;
  rightDetect = xLoc+radius;
  leftDetect = xLoc-radius;
  bottomDetect = yLoc+radius;
}

function detectionLocTest(){
  color(150);
  circle(xLoc,topDetect,5);
  color(165);
  circle(rightDetect,yLoc,5);
  color(135);
  circle(leftDetect,yLoc,5);
  color(180);
  circle(xLoc,bottomDetect,5);
  color(255);
}

function dumbCircle(){
  circle(whatX,whatY,10);
  whatX+=2;
  whatY+=2;
  if(whatX >= width && whatY >= height){
    whatX = random(100,300);
    whatY = random(100, 300);
  }
}

function bounceTrack(){
  stroke(255);
  fill(255);
  text(bounces,textX,textY);
  if(shake > 0){
    textX = random(width/1.95,width/2.05);
    textY = random(height/1.95,height/2.05);
    shake--;
  }else{
    textX = width/2;
    textY = height/2;
  }
  stroke(0);
}