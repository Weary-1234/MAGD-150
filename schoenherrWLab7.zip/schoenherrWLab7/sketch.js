//what I wanted to do
let theDeck = [];
let drawnCards = [];

//what I did after figuring out there is more to the assignment
let numbers1 = [];
let numbers2 = [];
let randNumbers1 = [];
let randNumbers2 = [];
let randNumbEnd = [];

function setup() {
  createCanvas(400, 400);
  background(255);
  makeTheDeck();
  showDeck();
  cardDraw();
  showDrawn();
  showRemainingDeck();
  line(0,200, width, 200)
  numSet();
  numRand();
  showDumbNumbers();
}

function makeTheDeck(){
  //Set The Clubs
  for(let c = 1; c <= 13; c++){
    if(c==1){
      theDeck.push("Ace of Clubs");
    }else if(c==11){
      theDeck.push("Jack of Clubs");
    }else if(c==12){
      theDeck.push("Queen of Clubs");
    }else if(c==13){
      theDeck.push("King of Clubs");
    }else{
      theDeck.push(c + " of Clubs");
    }
  }
  //Set the Spades
  for(let s = 1; s <= 13; s++){
    if(s==1){
      theDeck.push("Ace of Spades");
    }else if(s==11){
      theDeck.push("Jack of Spades");
    }else if(s==12){
      theDeck.push("Queen of Spades");
    }else if (s==13){
      theDeck.push("King of Spades");
    }else{
      theDeck.push(s + " of Spades");
    }
  } 
  //Set the Hearts
  for(let h = 1; h <= 13; h++){
    if(h==1){
      theDeck.push("Ace of Hearts");
    }else if(h==11){
      theDeck.push("Jack of Hearts");
    }else if(h==12){
      theDeck.push("Queen of Hearts");
    }else if (h==13){
      theDeck.push("King of Hearts");
    }else{
      theDeck.push(h + " of Hearts");
    }
  } 
  //Set the Diamonds
  for(let d = 1; d <= 13; d++){
    if(d==1){
      theDeck.push("Ace of Diamonds");
    }else if(d==11){
      theDeck.push("Jack of Diamonds");
    }else if(d==12){
      theDeck.push("Queen of Diamonds");
    }else if (d==13){
      theDeck.push("King of Diamonds");
    }else{
      theDeck.push(d + " of Diamonds");
    }
  } 
}

function cardDraw(){
  //draws 5 cards
  for(let x = 0; x<5;x++){
    let num = Math.floor(random(0,theDeck.length));
    console.log(num + ": " + theDeck[num]);
    drawnCards.push(theDeck[num]);
    theDeck.splice(num,1);
  }
}

function numSet(){
  for(let x = 0; x<25; x++){
    numbers1.push(Math.floor(random(0,1000)));
    numbers2.push(Math.floor(random(0,1000)));
  }
  console.log(numbers1);
  console.log(numbers2);
}

function numRand(){
  for(let x = 0; x<10; x++){
    let num = Math.floor(random(0,numbers1.length));
    console.log(num + ": " + numbers1[num]);
    randNumbers1.push(numbers1[num]);
    numbers1.splice(num,1);
  }
  for(let f = 0; f<10; f++){
    let num = Math.floor(random(0,numbers2.length));
    console.log(num + ": " + numbers2[num]);
    randNumbers2.push(numbers2[num]);
    numbers2.splice(num,1);
  }
  for(let e = 0; e<5; e++){
    let rand = Math.floor(random());
    if(rand == 0){
      let num = Math.floor(random(0,randNumbers1.length));
      console.log(num + ": " + randNumbers1[num]);
      randNumbEnd.push(randNumbers1[num]);
      randNumbers1.splice(num,1);
    }else if (rand == 1){
      let num = Math.floor(random(0,randNumbers2.length));
      console.log(num + ": " + randNumbers2[num]);
      randNumbEnd.push(randNumbers2[num]);
      randNumbers2.splice(num,1);
    }
  }
}

//All functions with the goal of showing stuff on the canvas will be below
function showDeck(){
  textSize(12);
  text("Deck:", 10, 15);
  textSize(7);
  text(theDeck,10,20, width-10);
}
function showDrawn(){
  console.log(drawnCards)
  textSize(12);
  text("Drawn Cards:", 10, 85);
  text(drawnCards, 10, 90, width-10);
}
function showRemainingDeck(){
  console.log(theDeck)
  textSize(12);
  text("Remaining Deck:", 10, 125);
  textSize(7);
  text(theDeck,10,130, width-10);
}
function showDumbNumbers(){
  //step 3
  textSize(10);
  text("RandoNumbees Step 3:", 10, 210);
  textSize(10);
  text(randNumbEnd,10,214, width-10);

  //step 2
  textSize(10);
  text("RandoNumbees Step 2 Part A Remaining:", 10, 235);
  textSize(10);
  text(randNumbers1,10,239, width-10);
  textSize(10);
  text("RandoNumbees Step 2 Part B Remaining:", 10, 260);
  textSize(10);
  text(randNumbers2,10,264, width-10);

  //step 1
  textSize(10);
  text("RandoNumbees Step 1 Part A Remaining:", 10, 285);
  textSize(10);
  text(numbers1,10,289, width-10);
  textSize(10);
  text("RandoNumbees Step 1 Part A Remaining:", 10, 310);
  textSize(10);
  text(numbers2,10,314, width-10);
}