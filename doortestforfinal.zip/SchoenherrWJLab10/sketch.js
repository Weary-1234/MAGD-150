//Used to lock door control while an animation is playing
let lock = 0;
//Used to tell the program the state of the door. Open = true : Closed = false
let doorState = false;

let doorY = 100;

let doorFrame = [[-50,-100], [50,-100], [50,100], [-50,100]];

//door?

function setup() {
  createCanvas(400, 400, WEBGL);
  brush.add("glitch", {
    type:    "marker",
    weight:  9,
    scatter: 15,
    opacity: 1.62,
    spacing: 0.338,
    noise:   1,
    pressure: [2, 2],
    rotate:  "none",
    markerTip: true,
  });
  brush.scaleBrushes(.2);
  brush.set("glitch", "#A3A3A3", 1.4);

}

function draw() {
  background(20);

  door();
}

function door(){
  fill(200)
  doorSides = [[-50,-100], [50,-100], [50,doorY], [-50,doorY]];
  quad(-50,-100, 50,-100, 50,doorY, -50,doorY);
  brush.stroke("#A3A3A3");
  brush.line(50,doorY, -50,doorY);
  brush.polygon(doorFrame);
  brush.stroke("#000000");
  fill(0)
  brush.line(-20,doorY-10, 20,doorY-10);
  line(-20,doorY-10, 20,doorY-10);
  if(lock != 0){
    lock--
    if(doorState){
      doorY-=15;
    }else if(!doorState){
      doorY+=15;
    }
    //console.log(lock);
  }
}

function keyPressed(){
  if (keyCode == 32 && lock == 0){
    lock = 10;
    doorState = !doorState
    //console.log(doorState);
  }
}
